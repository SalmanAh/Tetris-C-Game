                                //////////       Salman Ahmed_i22-0743_PF-Project       ///////////

/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 
 int BLOCKS[8][4] = { {0,1,2,3} , {1,3,5,7} , {2,4,5,7} , {0,1,3,5} , {0,2,3,4} , {1,3,2,4} , {1,2,3,4} , {1,1,1,1} } ;
