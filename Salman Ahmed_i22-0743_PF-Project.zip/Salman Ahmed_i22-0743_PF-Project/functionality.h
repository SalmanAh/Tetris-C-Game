                              //////////       Salman Ahmed_i22-0743_PF-Project       ///////////

/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */

//---Piece Starts to Fall When Game Starts---//

void fallingPiece(float& timer, float& delay , int& colorNum , int BLOCKS[8][4]){
    if (timer>delay){
        for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            point_1[i][1]+=1;                   //How much units downward
        }
        

          
        if (!anamoly())
        {
          for(int i=0 ; i<4 ; i++)
          {
          gameGrid[point_2[i][1]][point_2[i][0]] = colorNum ;
          }
                    colorNum = 1 + rand()%7;
            int n=rand()%8;
            //--- Un-Comment this Part When You Make BLOCKS array---//
            
                   for (int i=0;i<4;i++)
                   {
                    point_1[i][0] = BLOCKS[n][i] % 2;
                    point_1[i][1] = BLOCKS[n][i] / 2;
                   }
            
        }
        timer=0;
    }
}

/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///
   
                                  ///////////////    Left Movement    /////////////////
   
   void Mleft()                     
   {
      for(int i=0; i<4; i++)
       {
         point_1[i][0]-=1;
       } 
   }
   
                                 ///////////////    Right Movement    /////////////////
                                 
   void Mright()
   {
     for(int i=0; i<4; i++)
      {
        point_1[i][0]+=1;
      }
   }
                                 ///////////////    Rotation gets on    ////////////////
                                 
   void BRot()
   {
      for(int i=0 ; i<4 ; i++)
       { 
     
          int temp = point_1[i][0]  ;                      
          point_1[i][0] = point_1[i][1] ;
          point_1[i][1] = temp ;

          }
       }
                                      ////////////    Rotation in boundary    /////////////
                                                    
    void RotGrid()
    {
      if(!anamoly())
       {
        for(int i=0 ; i<4 ; i++)
         {
           point_1[i][0] = point_2[i][0] ;
           point_1[i][1] = point_2[i][1] ;
         }
       }
    }
    
                                      ///////////////    Line Clearing     ///////////////
    
   int LinClr(int& Marks)
   {
     int i , j , k , count ;
     for(i=0 ; i<20 ; i++)
     {
        count = 0 ;
     
       for(j=0 ; j<10 ; j++)
       {
         if(gameGrid[i][j] != 0)
         {
           count++ ;
         }         
       }
         if(count==10)                      
        {
         for(k=0 ; k<10 ; k++)
         {
           gameGrid[i][k] = {0} ; 
     }  Marks += 10 ;    
         }
                                      ////////////////     Making all lines fall    //////////////////
         if(count==10)
         {
          for(int m=i ; m>0 ; m--)
           for(int l=0 ; l<10 ; l++)
           {
           gameGrid[m][l] = gameGrid[m-1][l] ;
           gameGrid[m-1][l] = {0} ;
           }
         }
         
       } 
     return Marks;
   }
   

///*** YOUR FUNCTIONS END HERE ***///
/////////////////////////////////////
